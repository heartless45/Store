from django.shortcuts import render
from .models import Store
# Create your views here.

def home(request):
    Item = Store.objects.all()
    return render(request ,'1.html',{'Item': Item})